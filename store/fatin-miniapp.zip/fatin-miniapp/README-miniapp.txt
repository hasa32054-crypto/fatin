Fatin mini-app package
- Put Tawakkalna's twkhelper.js (from the partner portal) next to index.html before uploading.
- Reads only the first name and gender through the SDK, to greet the person (stays on the device).
- Host messages (postMessage): see docs/integration.md
Independent student project by Hassan Abdullah Alyenbawi. Not affiliated with any government body or bank.
